﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace CRUDA
{
    public partial class StudentResult : Form
    {
        public StudentResult()
        {
            InitializeComponent();
        }

        String Name;
        int ID;



        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }


        private void lblRecordSignal_Click(object sender, EventArgs e)
        {

        }


        private void btnCreateAccount_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {

        }



        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }



        private void gbx_Enter(object sender, EventArgs e)
        {

        }


        private void lblSignUp_Click(object sender, EventArgs e)
        {

        }


        private void StudentResult_Load(object sender, EventArgs e)
        {

            var con2 = Configuration.getInstance().getConnection();
            SqlCommand cmd2 = new SqlCommand("Select *  from Assessment", con2);
            SqlDataAdapter da = new SqlDataAdapter(cmd2);
            DataTable dt = new DataTable();
            da.Fill(dt);
            datagridView.DataSource = null;
            datagridView.DataSource = dt;
            datagridView.DefaultCellStyle.ForeColor = Color.Black;

            DataGridViewButtonColumn Update = new DataGridViewButtonColumn();
            Update.HeaderText = "Evaluate";
            Update.Text = "Evaluate";
            Update.UseColumnTextForButtonValue = true;
            DataGridViewButtonColumn Delete = new DataGridViewButtonColumn();
            Delete.HeaderText = "Result";
            Delete.Text = "Result";
            Delete.UseColumnTextForButtonValue = true;
            datagridView.Columns.Add(Update);
            datagridView.Columns.Add(Delete);
        }



        private void datagridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void datagridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                Name = datagridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                ID = Convert.ToInt16(datagridView.Rows[e.RowIndex].Cells[2].Value.ToString());

               

            }
            catch (Exception exp) { }
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
